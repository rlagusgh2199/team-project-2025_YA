"""
OpenAI GPT API를 사용하여 자연어 응답을 생성합니다.
"""
import json
from typing import Dict, Optional, List
from pathlib import Path
from openai import OpenAI
from config import JSON_DATA_PATH, OPENAI_API_KEY, OPENAI_MODEL, LLM_TIMEOUT


class LLMService:
    """OpenAI GPT API 기반 자연어 응답 서비스"""

    def __init__(self):
        """OpenAI API 초기화"""
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.model = OPENAI_MODEL

    def ask_route(self, user_query: str) -> Dict:
        """OpenAI GPT API를 사용하여 사용자 질문에 응답"""
        data_json = self._load_data_json()

        # JSON 데이터에서 관련 정보 찾기
        facilities: List[Dict] = data_json.get('facilities', [])
        map_nodes: List[Dict] = data_json.get('map_nodes', [])
        matches = self._find_facility_matches(user_query, facilities)

        # OpenAI GPT API를 사용하여 자연스러운 응답 생성
        try:
            if not matches:
                # 매칭되는 시설이 없을 때
                prompt = f"""사용자가 "{user_query}"라고 물어봤습니다.
하지만 해당 시설 정보를 찾지 못했습니다.
정확한 명칭을 다시 말씀해 달라고 친절하게 안내해주세요. (한국어로, 2-3문장)"""

                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    timeout=LLM_TIMEOUT
                )
                response_text = response.choices[0].message.content
                return {
                    'query': user_query,
                    'response': response_text + " [[TARGET_ID:None]]",
                    'target_id': "None",
                    'data_loaded': bool(data_json),
                }

            # 매칭되는 시설이 있을 때
            building_names = {m.get('building') for m in matches if m.get('building')}

            if len(matches) > 3 and len(building_names) == 1:
                # 건물 전체 시설 안내
                bld = next(iter(building_names))
                floor_map = {}
                for m in matches:
                    floor = m.get('floor', '정보없음')
                    floor_map.setdefault(floor, []).append(m.get('facility', ''))

                floor_info = ""
                for floor, facs in sorted(floor_map.items()):
                    fac_list = ', '.join(f for f in facs if f)
                    floor_info += f"- {floor}: {fac_list}\n"

                target_id = self._find_building_id(bld, map_nodes) or "None"
                region_hint = self._region_hint(bld)

                prompt = f"""사용자가 "{user_query}"라고 물어봤습니다.
{bld}에 있는 시설 목록입니다:
{floor_info}
{region_hint}

위 정보를 바탕으로 친절하고 자연스럽게 안내해주세요. (한국어로, 3-4문장)"""

                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    timeout=LLM_TIMEOUT
                )
                response_text = response.choices[0].message.content
                return {
                    'query': user_query,
                    'response': response_text + f" [[TARGET_ID:{target_id}]]",
                    'target_id': target_id,
                    'data_loaded': bool(data_json),
                }

            # 단일 시설 안내
            dest = matches[0]
            building = dest.get('building', '')
            floor = dest.get('floor', '')
            facility = dest.get('facility', '')

            target_id = self._find_building_id(building, map_nodes) or "None"
            region_hint = self._region_hint(building)

            prompt = f"""사용자가 "{user_query}"라고 물어봤습니다.
{facility}은 {building} {floor}에 있습니다.
{region_hint}

위 정보를 바탕으로 친절하고 자연스럽게 길을 안내해주세요. (한국어로, 2-3문장)"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                timeout=LLM_TIMEOUT
            )
            response_text = response.choices[0].message.content
            return {
                'query': user_query,
                'response': response_text + f" [[TARGET_ID:{target_id}]]",
                'target_id': target_id,
                'data_loaded': bool(data_json),
            }

        except Exception as e:
            # OpenAI API 호출 실패 시 기본 응답으로 폴백
            response, target_id = self._answer_from_data(user_query, data_json)
            return {
                'query': user_query,
                'response': response,
                'target_id': target_id,
                'data_loaded': bool(data_json),
                'error': f'OpenAI API 오류: {str(e)}'
            }

    def _load_data_json(self) -> Dict:
        """locations.json을 로드 (map_nodes, facilities 포함)"""
        try:
            path = Path(JSON_DATA_PATH)
            with path.open(encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _answer_from_data(self, user_query: str, data_json: Dict) -> (str, Optional[str]):
        facilities: List[Dict] = data_json.get('facilities', [])
        map_nodes: List[Dict] = data_json.get('map_nodes', [])

        matches = self._find_facility_matches(user_query, facilities)
        if not matches:
            return "죄송합니다. 해당 시설 정보를 찾지 못했습니다. 정확한 명칭을 말씀해 주세요. [[TARGET_ID:None]]", "None"

        # 건물명만 주어진 경우: 건물 내 시설들을 층별로 요약해 제공
        building_names = {m.get('building') for m in matches if m.get('building')}
        if len(matches) > 3 and len(building_names) == 1:
            bld = next(iter(building_names))
            floor_map = {}
            for m in matches:
                floor = m.get('floor', '정보없음')
                floor_map.setdefault(floor, []).append(m.get('facility', ''))
            lines = []
            for floor, facs in sorted(floor_map.items()):
                fac_list = ', '.join(f for f in facs if f)
                lines.append(f"- {floor}: {fac_list}")
            target_id = self._find_building_id(bld, map_nodes) or "None"
            region_hint = self._region_hint(bld)
            guide = f"{bld}에 있는 시설 목록입니다:\n" + "\n".join(lines)
            return f"{guide}\n{region_hint} [[TARGET_ID:{target_id}]]", target_id

        # 단일 혹은 소수 → 첫 번째 사용
        dest = matches[0]
        building = dest.get('building', '')
        floor = dest.get('floor', '')
        facility = dest.get('facility', '')

        target_id = self._find_building_id(building, map_nodes)
        region_hint = self._region_hint(building)

        guide = f"{facility}은 {building} {floor}에 있습니다. {region_hint}"
        tag = f"[[TARGET_ID:{target_id or 'None'}]]"
        return f"{guide} {tag}", target_id or "None"

    def _find_facility_matches(self, query: str, facilities: List[Dict]) -> List[Dict]:
        q = query.lower()
        results = []
        for f in facilities:
            name = f.get('facility', '')
            bld = f.get('building', '')
            if (name and name.lower() in q) or (bld and bld.lower() in q):
                results.append(f)
        return results

    def _find_building_id(self, building: str, map_nodes: List[Dict]) -> Optional[str]:
        for node in map_nodes:
            if node.get('type') == 'building' and node.get('name') == building:
                return node.get('id')
        return None

    def _region_hint(self, building: str) -> str:
        flat = {'1호관', '2호관', '8호관'}
        hill = {'3호관', '4호관', '5호관', '6호관', '7호관', '운동장'}
        if building in flat:
            return "정문 평지 구역에 있어 바로 이동하시면 됩니다."
        if building in hill:
            return "언덕 위에 있으니 가까운 계단을 이용해 올라가세요."
        return "캠퍼스 내 위치입니다. 안내 표지판을 참고하세요."

